<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 10 Modified in v1.5.7 $
 */

 define('MODULE_ORDER_TOTAL_COUPON_TITLE', 'קופוני הנחה');
 define('MODULE_ORDER_TOTAL_COUPON_HEADER', TEXT_GV_NAMES . '/קופוני הנחה');
 define('MODULE_ORDER_TOTAL_COUPON_DESCRIPTION', 'קופוני הנחה');
 define('MODULE_ORDER_TOTAL_COUPON_TEXT_ENTER_CODE', TEXT_GV_REDEEM);
 define('MODULE_ORDER_TOTAL_COUPON_REDEEM_INSTRUCTIONS', '<p>אנא הכנס את קוד קופון ההנחה. סכום ההנחה ינוכה מהסכום הסופי לאחר שתלחץ על המשך.</p><p>לתשומת לבך: ניתן להשתמש בקופון אחד לכל הזמנה.</p>');
 define('MODULE_ORDER_TOTAL_COUPON_TEXT_CURRENT_CODE', 'קוד הקופון הנוכחי הוא: ');
 define('TEXT_COMMAND_TO_DELETE_CURRENT_COUPON_FROM_ORDER', 'REMOVE');
 define('MODULE_ORDER_TOTAL_COUPON_REMOVE_INSTRUCTIONS', '<p>להסרת השובר הקלד REMOVE ולחץ אנטר</p>');
 define('TEXT_REMOVE_REDEEM_COUPON', 'קופון הנחה הוסר לבקשתך!');
 define('MODULE_ORDER_TOTAL_COUPON_INCLUDE_ERROR', ' Setting Include tax = true, should only happen when recalculate = None');

 define('SHIPPING_NOT_INCLUDED', ' [משלוח לא כלול]');
 define('TAX_NOT_INCLUDED', ' [מס לא כלול]');
 define('IMAGE_REDEEM_VOUCHER', 'פדה קופון');
