<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2019 Jul 20 Modified in v1.5.7 $
 */

 define('MODULE_ORDER_TOTAL_GV_TITLE', TEXT_GV_NAMES);
 define('MODULE_ORDER_TOTAL_GV_HEADER', TEXT_GV_NAMES . '/קופוני הנחה');
 define('MODULE_ORDER_TOTAL_GV_DESCRIPTION', TEXT_GV_NAMES);
 define('MODULE_ORDER_TOTAL_GV_USER_PROMPT', 'כמות: ');
 define('MODULE_ORDER_TOTAL_GV_TEXT_ENTER_CODE', TEXT_GV_REDEEM);
 define('TEXT_INVALID_REDEEM_AMOUNT', 'נראה שהכמות אותה בחרת והכמות הזמינה בקופון לא זהות. אנא נסה בשנית.');
 define('MODULE_ORDER_TOTAL_GV_USER_BALANCE', 'קרדיט זמין: ');
 define('MODULE_ORDER_TOTAL_GV_REDEEM_INSTRUCTIONS', '<p>בשביל להשתמש בקרדיט הזמין בכרטיס המתנה שברשותך, הכנס את הסכום בתיבה \'כמות\'. תצטרך לבחור דרך תשלום, ואז ללחוץ על כפתור ההמשך על מנת שהסכום יטען לקופה.</p><p>אם ברשותך כרטיס מתנה<em>חדש</em> עליך להכניס את הקוד שלו ליד התיבה המתאימה.</p>');
 define('MODULE_ORDER_TOTAL_GV_INCLUDE_ERROR', ' Setting Include tax = true, should only happen when recalculate = None');

 define('SHIPPING_NOT_INCLUDED', ' [משלוח לא כלול]');
 define('TAX_NOT_INCLUDED', ' [מס לא כלול]');
