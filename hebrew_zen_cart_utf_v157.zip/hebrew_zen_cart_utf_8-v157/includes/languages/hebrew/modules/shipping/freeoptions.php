<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: freeoptions.php 3830 2006-06-21 23:47:16Z ajeh $
 */

define('MODULE_SHIPPING_FREEOPTIONS_TEXT_TITLE', 'אפשרויות משלוח חינם');
define('MODULE_SHIPPING_FREEOPTIONS_TEXT_DESCRIPTION', 'אם מופיעה אפשרות זו. זה אומר שניתן לקבל הזמנה זו ללא עלות משלוח.');
define('MODULE_SHIPPING_FREEOPTIONS_TEXT_WAY', 'המשלוח חינם ישנה רק עלות טיפול');

?>