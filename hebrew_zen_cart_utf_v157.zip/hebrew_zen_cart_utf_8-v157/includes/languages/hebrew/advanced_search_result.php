<?php

/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2019 Jul 27 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE_1', 'חיפוש מתקדם');
define('NAVBAR_TITLE_2', 'תוצאות החיפוש');

//define('HEADING_TITLE_1', 'Advanced Search');
define('HEADING_TITLE', 'חיפוש מתקדם');

define('HEADING_SEARCH_CRITERIA', 'חיפוש');

define('TEXT_SEARCH_IN_DESCRIPTION', 'חפש לפי תיאור');
define('ENTRY_CATEGORIES', 'קטגוריות:');
define('ENTRY_INCLUDE_SUBCATEGORIES', 'כלול קטגוריות משנה בחיפוש');
define('ENTRY_MANUFACTURERS', 'יצרנים:');
define('ENTRY_PRICE_FROM', 'מחיר התחלתי:');
define('ENTRY_PRICE_TO', 'מחיר סופי:');
define('ENTRY_DATE_FROM', 'מתאריך:');
define('ENTRY_DATE_TO', 'עד תאריך:');

define('TEXT_SEARCH_HELP_LINK', 'עזרה [?]');

define('TEXT_ALL_CATEGORIES', 'כל הקטגוריות');
define('TEXT_ALL_MANUFACTURERS', 'כל היצרנים');

define('HEADING_SEARCH_HELP', 'עזרה');
define('TEXT_SEARCH_HELP', 'Keywords may be separated by AND and/or OR statements for greater control of the search results.<br /><br />For example, Microsoft AND mouse would generate a result set that contain both words. However, for mouse OR keyboard, the result set returned would contain both or either words.<br /><br />Exact matches can be searched for by enclosing keywords in double-quotes.<br /><br />For example, "notebook computer" would generate a result set which match the exact string.<br /><br />Brackets can be used for further control on the result set.<br /><br />For example, Microsoft and (keyboard or mouse or "visual basic").');
define('TEXT_CLOSE_WINDOW', 'סגור [x]');

define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'דגם');
define('TABLE_HEADING_PRODUCTS', 'שם המוצר');
define('TABLE_HEADING_MANUFACTURER', 'יצרן');
define('TABLE_HEADING_QUANTITY', 'כמות');
define('TABLE_HEADING_PRICE', 'מחיר');
define('TABLE_HEADING_WEIGHT', 'משקל');
define('TABLE_HEADING_BUY_NOW', 'הזמן');

define('TEXT_NO_PRODUCTS', 'לא נמצאו מוצרים.');

define('ERROR_AT_LEAST_ONE_INPUT', 'לפחות אחד משדות החיפוש צריך להיות מלא.');
define('ERROR_INVALID_FROM_DATE', 'תאריך \'מ\' לא קביל.');
define('ERROR_INVALID_TO_DATE', 'תאריך \'עד\' לא קביל.');
define('ERROR_TO_DATE_LESS_THAN_FROM_DATE', 'תאריך \'עד\' צריך להיות אחרי או שווה לתאריך \'מ\'.');
define('ERROR_PRICE_FROM_MUST_BE_NUM', 'מחיר התחלתי צריך להיות מספר.');
define('ERROR_PRICE_TO_MUST_BE_NUM', 'מחיר סופי צריך להיות מספר.');
define('ERROR_PRICE_TO_LESS_THAN_PRICE_FROM', 'מחיר סופי צריך להיות גדול או שווה למחיר התחלתי.');
define('ERROR_INVALID_KEYWORDS', 'מילות חיפוש לא קבילות.');
