<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 10 Modified in v1.5.7 $
 */


define('NAVBAR_TITLE_1', 'החשבון שלי');
define('NAVBAR_TITLE_2', 'עדכוני מוצר');

define('HEADING_TITLE', 'עדכוני מוצר');

define('MY_NOTIFICATIONS_TITLE', 'עדכוני המוצר שלי');
define('MY_NOTIFICATIONS_DESCRIPTION', 'מאפשר לך להישאר מעודכן/ת בכל מיני עדכוני מוצרים אשר מעניינים אותך.');

define('GLOBAL_NOTIFICATIONS_TITLE', 'עדכונים על כל המוצרים');
define('GLOBAL_NOTIFICATIONS_DESCRIPTION', 'קבל/י עדכונים על כל המוצרים.');

define('NOTIFICATIONS_TITLE', 'עדכוני מוצרים');
define('NOTIFICATIONS_DESCRIPTION', 'לביטול הרשמה לעדכוני מוצר הסר/י את הסימון ליד העדכון.');
define('NOTIFICATIONS_NON_EXISTING', 'כרגע אין מוצרים אשר ביקשת לקבל עליהם עדכון<br /><br />בשביל לקבל עדכונים על מוצר. לחץ על הקישור בדף המוצר.');
define('TEXT_NO_PURCHASES', 'אין רכישות');

define('SUCCESS_NOTIFICATIONS_UPDATED', 'עדכוני המוצרים שלך עודכנו בהצלחה.');
