<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2019 Jul 27 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE_1', 'חיפוש מתקדם');
define('NAVBAR_TITLE_2', 'תוצאות החיפוש');

define('HEADING_TITLE_1', 'חיפוש מתקדם');
define('HEADING_TITLE_2', 'מוצרים התואמים את מילות החיפוש');

define('HEADING_SEARCH_CRITERIA', 'חיפוש');

define('TEXT_SEARCH_IN_DESCRIPTION', 'חפש בתוך תיאור');
define('ENTRY_CATEGORIES', 'קטגוריות:');
define('ENTRY_INCLUDE_SUBCATEGORIES', 'כולל קטגוריות משנה');
define('ENTRY_MANUFACTURERS', 'יצרנים:');
define('ENTRY_PRICE_FROM', 'ממחיר:');
define('ENTRY_PRICE_TO', 'עד מחיר:');
define('ENTRY_DATE_FROM', 'מתאריך:');
define('ENTRY_DATE_TO', 'עד תאריך:');
define('ENTRY_DATE_RANGE', 'חפש על פי תאריך הוספה');
define('TEXT_SEARCH_HELP_LINK', 'עזרה [?]');

define('TEXT_ALL_CATEGORIES', 'כל הקטגוריות');
define('TEXT_ALL_MANUFACTURERS', 'כל היצרנים');

define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'מודל');
define('TABLE_HEADING_PRODUCTS', 'שם המוצר');
define('TABLE_HEADING_MANUFACTURER', 'יצרן');
define('TABLE_HEADING_QUANTITY', 'כמות');
define('TABLE_HEADING_PRICE', 'מחיר');
define('TABLE_HEADING_WEIGHT', 'משקל');
define('TABLE_HEADING_BUY_NOW', 'הזמן');

define('TEXT_NO_PRODUCTS', 'לא נמצאו מוצרים התואמים את החיפוש אשר הזנת.');
define('KEYWORD_FORMAT_STRING', 'מילות מפתח');
define('ERROR_AT_LEAST_ONE_INPUT', 'חייב לפחות פרמטר חיפוש אחד.');
define('ERROR_INVALID_FROM_DATE', 'תאריך התחלתי שגוי.');
define('ERROR_INVALID_TO_DATE', 'תאריך סופי שגוי.');
define('ERROR_TO_DATE_LESS_THAN_FROM_DATE', 'תאריך התחלתי חייב להיות קטן או שווה לתאריך הסופי.');
define('ERROR_PRICE_FROM_MUST_BE_NUM', 'מחיר חייב להיות מספר.');
define('ERROR_PRICE_TO_MUST_BE_NUM', 'מחיר חייב להיות מספר.');
define('ERROR_PRICE_TO_LESS_THAN_PRICE_FROM', 'מחיר התחלתי חייב להיות קטן או שווה למחיר הסופי.');
define('ERROR_INVALID_KEYWORDS', 'מילות חיפוש שגויות.');

