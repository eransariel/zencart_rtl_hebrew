<?php
/**
 * @copyright Copyright 2003-2021 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Eran Ariel 2021 modified in v1.5.7b $
 */

define('NAVBAR_TITLE', 'צור חשבון');

define('HEADING_TITLE', 'יצירת חשבון חדש');

define('ERROR_CREATE_ACCOUNT_SPAM_DETECTED', 'תודה, בקשה לפתיחת חשבון מועבר לבדיקה ואישור');


define('TEXT_ORIGIN_LOGIN', '<strong class="note">הערה:</strong> במידע וכבר יש לך חשבון אצלנו, אנא לחץ <a href="%s">כאן</a> בכדי להירשם.');

// greeting salutation
define('EMAIL_SUBJECT', 'ברוכים הבאים ל'.STORE_NAME.'!');
define('EMAIL_GREET_MR', '<p align=right>שלום %s'. "\n\n");
define('EMAIL_GREET_MS', '<p align=right>שלום %s'. "\n\n");
define('EMAIL_GREET_NONE', '<p align=right>שלום %s'. "\n\n");

// First line of the greeting
define('EMAIL_WELCOME', '<p align="right"><strong>שלום וברוכים הבאים לחנות </strong><a href="' . HTTP_SERVER . DIR_WS_CATALOG . '">'.STORE_NAME ."</a>\n\n");
define('EMAIL_SEPARATOR', '--------------------');
define('EMAIL_COUPON_INCENTIVE_HEADER', 'איחולי! על מנת שביקורך בחנות יהיה מהנה יותר, פרטי קופון הנחה שנוצר במיוחד בשבילך מחכים לך' . "nn");
// your Discount Coupon Description will be inserted before this next define
define('EMAIL_COUPON_REDEEM', 'בשביל להשתמש בקופון ההנחה, הכנס/י את קוד ה-' . TEXT_GV_REDEEM . ':<br /> %s בעת התשלום.' . "nn");
define('TEXT_COUPON_HELP_DATE', '<p>הקופון תקף בין %s ל %s</p>');

define('EMAIL_GV_INCENTIVE_HEADER', 'בשביל שתבוא/י היום, שלחנו לך ' . TEXT_GV_NAME . ' עבור %s!' . "nn");
define('EMAIL_GV_REDEEM', 'ה-' . TEXT_GV_NAME . ' ' . TEXT_GV_REDEEM . ' הוא: %s ' . "nn" . 'ניתן להכניס את ' . TEXT_GV_REDEEM . ' בעת התשלום, אחרי בחירת המוצרים בחנות.' . "nn");
define('EMAIL_GV_LINK', 'או, ניתן לפדות אותו בקישור הבא: ' . "nn");
// GV link will automatically be included before this line

define('EMAIL_GV_LINK_OTHER','ברגע שהוספת את ' . TEXT_GV_NAME . ' לחשבונך, ניתן להשתמש ב' . TEXT_GV_NAME . ' לעצמך, א לשלוח אותו לחבר!' . "nn");

define('EMAIL_TEXT', '<p align=right>אנו שמחים שהחלטת להצטרף למעגל לקוחותינו. בכל שאלה שיש לך, אתה מוזמן לפנות אלינו ואנו נשתדל לספק את התשובה הכי אמינה והכי מהירה. כמו כן, אם הנך צריך פריט אשר לא קיים בחנותינו, אתה מוזמן לפנות לשירות הלקוחות ואנו נשתדל למצוא או ליצור עבורך את הפריט המבוקש.'."\n\n");
define('EMAIL_CONTACT', '<p align=right>אם הנך מתקשה בתפעול החנות או שיש לך שאלות אחרות, אנא פנה למחלקת שירות הלקוחות: ' . STORE_OWNER_EMAIL_ADDRESS . "\n\n");
define('EMAIL_GV_CLOSURE','<p align=right>בכבוד והוקרה,' . "\n" . STORE_OWNER . "\n\n" .'<a href="' . HTTP_SERVER . DIR_WS_CATALOG . '">'.HTTP_SERVER ."</a>\n\n");

// email disclaimer - this disclaimer is seperate from all other email disclaimers
define('EMAIL_DISCLAIMER_NEW_CUSTOMER', '<p align="right">מכתב הזה הגיעה עליך כי אתה או מישהו שיודעה את כתובתך נרשם לחנותינו. אם אתה חש שמכתב הזה הגיעה עליך בטעות צור איתנו כשר ואנחנו נטפל בסוגיה %s');

//moved definitions to english.php
//define('TABLE_HEADING_PRIVACY_CONDITIONS', 'Privacy Statement');
//define('TEXT_PRIVACY_CONDITIONS_DESCRIPTION', 'Please acknowledge you agree with our privacy statement by ticking the following box. The privacy statement can be read <a href="' . zen_href_link(FILENAME_PRIVACY, '', 'SSL') . '"><span class="pseudolink">here</span></a>.');
//define('TEXT_PRIVACY_CONDITIONS_CONFIRM', 'I have read and agreed to your privacy statement.');
//define('TABLE_HEADING_ADDRESS_DETAILS', 'Address Details');
//define('TABLE_HEADING_PHONE_FAX_DETAILS', 'Additional Contact Details');
//define('TABLE_HEADING_DATE_OF_BIRTH', 'Verify Your Age');
//define('TABLE_HEADING_LOGIN_DETAILS', 'Login Details');
//define('TABLE_HEADING_REFERRAL_DETAILS', 'Were You Referred to Us?');

