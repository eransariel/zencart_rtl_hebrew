<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: time_out.php 3027 2006-02-13 17:15:51Z drbyte $
 */

define('NAVBAR_TITLE', 'התחברות לא תקפה');
define('HEADING_TITLE', 'התחברות לא תקפה');
define('HEADING_TITLE_LOGGED_IN', 'אופס. מצטערים אבל את/ה לא רשאי/ת לבצע את הפעולה המבוקשת. ');
define('TEXT_INFORMATION', '<p>אם היית במהלך ביצוע הזמנה, אנא התחבר/י בשנית והעגלה תופיע בשנית. אז תוכל/י לחזור להמשך תהליך ביצוע ההזמנה.</p><p>אם סיימת לבצע הזמנה וברצונך לראות אותה' . (DOWNLOAD_ENABLED == 'true' ? ', או שהיית באמצע הורדה וברצונך להורידה בשנית' : '') . ', אנא גש/י <a href="' . zen_href_link(FILENAME_ACCOUNT, '', 'SSL') . '">לדף החשבון </a> שלך לבדוק את ההזמנה.</p>');

define('TEXT_INFORMATION_LOGGED_IN', 'את/ה עדיין מחובר/ת למערכת. אנא בחר/י מקום להגיע אליו מהתפריט הראשי.');
define('HEADING_RETURNING_CUSTOMER', 'התחבר');
define('TEXT_PASSWORD_FORGOTTEN', 'שכחת את הסיסמה?')
