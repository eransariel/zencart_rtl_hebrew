<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2019 Jul 27 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE', 'מוצרים מומלצים');
define('HEADING_TITLE', 'מוצרים מומלצים');

define('TEXT_DATE_ADDED', 'תאריך הוספה:');
define('TEXT_MANUFACTURER', 'יצרן:');
define('TEXT_PRICE', 'מחיר:');

define('TEXT_PRODUCTS_MODEL','דגם: ');
define('TEXT_PRODUCTS_WEIGHT','משקל: ');
define('TEXT_PRODUCTS_QUANTITY','במלאי: ');
define('TEXT_OUT_OF_STOCK','אין במלאי');
