<p> את הקובץ ניתן למצוא כאן includes/languages/hebrew/html_includes/define_shopping_cart.php</p>
<p>ניתן לערוך את הטקסט (שאתה קורא עכשיו) ב- אדמין > כלים > הגדר עורך דפים...על מנת לכתוב הודעות כאן בעגלת הקניות </p>


