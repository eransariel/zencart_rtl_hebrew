


<a href="https://docs.zen-cart.com/user/" target="_blank" rel="noopener">קישור לתיעוד המלא של זן קארט</a>
<p class="biggerText">מערכת התבניות מיישמת את הפן החזותי של האתר ומשתמשת ב-"PHP Mobile Detect" בכדי להגיש פריסה מותאמת למכשיר המשתמש.  
  אם הנך צופה באתר דרך מחשב וברצונך לצפות בעריכה\פריסה לטאבלט <a class="red" href="index.php?main_page=index&amp;layoutType=tablet">השתמש בקישור זה.</a>  
  אם ברצונך לצפות בעריכה\פריסה לסמארטפון <a class="red" href="index.php?main_page=index&amp;layoutType=mobile">השתמש בקישור זה.</a>  
  כדי לחזור לשולחן העבודה למחשב רגיל <a class="red" href="index.php?main_page=index&amp;layoutType=default">השתמש בקישור זה.</a></p>



<strong>
<p>הטקסט נמצא בקובץ: <code> /languages/hebrew/html_includes/YOUR_TEMPLATE/define_main_page.php</code></p>
<p>ניתן לערוך את תוכן הנ"ל דרך אדמין->כלים->הגדר ערוך פרטים</p>
<p>הערה: גבה תמיד את הקבצים שנמצאים ב-<code> /languages/hebrew/html_includes/your_template</code></p>
</strong>



