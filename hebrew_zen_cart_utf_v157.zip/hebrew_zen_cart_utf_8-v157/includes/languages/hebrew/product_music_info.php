<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: product_music_info.php 6371 2007-05-25 19:55:59Z ajeh $
 */

define('TEXT_PRODUCT_NOT_FOUND', 'סליחה, המוצר לא נמצא.');
define('TEXT_CURRENT_REVIEWS', 'ביקורות:');
define('TEXT_RECORD_COMPANY_URL', 'לעוד מידע אנא בקר <a href="%s" rel="noreferrer noopener" target="_blank">באתר חברת התקליטים</a>.');
define('TEXT_ARTIST_URL', 'לעוד מידע אנא בקר <a href="%s" rel="noreferrer noopener" target="_blank">באתר האמן</a>.');
define('TEXT_DATE_ADDED', 'מוצר זה נוסף לקטלוג ב%s.');
define('TEXT_DATE_AVAILABLE', 'מוצר זה יהיה זמין במלאי ב%s.');
define('TEXT_ALSO_PURCHASED_PRODUCTS', 'מי שקנה את זה קנה גם...');
define('TEXT_PRODUCT_OPTIONS', 'אנא בחר/י: ');
define('TEXT_PRODUCT_RECORD_COMPANY', 'חברת תקליטים: ');
define('TEXT_PRODUCT_ARTIST', 'אמן: ');
define('TEXT_PRODUCT_MUSIC_GENRE', 'סוג מוזיקה: ');
define('TEXT_PRODUCT_WEIGHT', 'משקל משלוח: ');
define('TEXT_PRODUCT_QUANTITY', ' יחידות במלאי');
define('TEXT_PRODUCT_MODEL', 'דגם: ');
define('TEXT_PRODUCT_COLLECTIONS', 'אוסף מדיה: ');



// previous next product
define('PREV_NEXT_PRODUCT', 'מוצרים ');
define('PREV_NEXT_FROM', ' מתוך ');
define('IMAGE_BUTTON_PREVIOUS','מוצר קודם');
define('IMAGE_BUTTON_NEXT','מוצר הבא');
define('IMAGE_BUTTON_RETURN_TO_PRODUCT_LIST','חזרה לרשימת המוצרים');

// missing products
//define('TABLE_HEADING_NEW_PRODUCTS', 'New Products For %s');
//define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Upcoming Products');
//define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');

define('TEXT_ATTRIBUTES_PRICE_WAS',' [היה: ');
define('TEXT_ATTRIBUTE_IS_FREE',' עכשיו הוא: חינם]');
define('TEXT_ONETIME_CHARGE_SYMBOL', ' *');
define('TEXT_ONETIME_CHARGE_DESCRIPTION', ' ייתכנו חיובים חד פעמיים');
define('TEXT_ATTRIBUTES_QTY_PRICE_HELP_LINK','הנחת כמות אפשרית');
define('ATTRIBUTES_QTY_PRICE_SYMBOL', zen_image(DIR_WS_TEMPLATE_ICONS . 'icon_status_green.gif', TEXT_ATTRIBUTES_QTY_PRICE_HELP_LINK, 10, 10) . '&nbsp;');

define('ATTRIBUTES_PRICE_DELIMITER_PREFIX', ' ( ');
define('ATTRIBUTES_PRICE_DELIMITER_SUFFIX', ' )');
define('ATTRIBUTES_WEIGHT_DELIMITER_PREFIX', ' (');
define('ATTRIBUTES_WEIGHT_DELIMITER_SUFFIX', ') ');
