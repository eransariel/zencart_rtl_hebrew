<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 10 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE_1', 'החשבון שלי');
define('NAVBAR_TITLE_2', 'ההיסטוריה ');

define('HEADING_TITLE', 'ההיסטוריה שלי');

define('TEXT_ORDER_NUMBER', 'מספר הזמנה: ');
define('TEXT_ORDER_STATUS', 'סטטוס ההזמנה: ');
define('TEXT_ORDER_DATE', 'תאריך ההזמנה: ');
define('TEXT_ORDER_SHIPPED_TO', 'נשלח ל-: ');
define('TEXT_ORDER_BILLED_TO', 'החויב: ');
define('TEXT_ORDER_PRODUCTS', 'פריטים: ');
define('TEXT_ORDER_COST', 'מחיר ההזמנה: ');

define('TEXT_NO_PURCHASES', 'טרם בוצעו הזמנות');
