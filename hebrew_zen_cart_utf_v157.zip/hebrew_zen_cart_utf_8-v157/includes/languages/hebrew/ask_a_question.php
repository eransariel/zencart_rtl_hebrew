<?php
/**
 * @copyright Copyright 2003-2021 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Eran Ariel 2021 modified in v1.5.7b $
 */

define('NAVBAR_TITLE', 'שאל שאלה');

define('HEADING_TITLE', 'שאל שאלה בנושא ');
define('FORM_TITLE', 'מה השאלה?');

define('TEXT_SUCCESS', 'ההודעה נשלחה בהצלחה');
define('EMAIL_SUBJECT', 'שאלה על פרט שנמכר בחנות ' . STORE_NAME);

define('ENTRY_NAME', 'שם מלא:');
define('ENTRY_EMAIL', 'כתובת דואר אלקטרוני');
define('ENTRY_TELEPHONE', 'מספר טלפון:');
define('ENTRY_ENQUIRY', 'הודעה:');
define('TEXT_PRODUCT_NAME', 'שם הפריט: ');

define('SEND_TO_TEXT','שלח מייל ל-:');
define('ENTRY_EMAIL_NAME_CHECK_ERROR','האם אין טעות באיות השם? המערכת זקוקה למינימום תווים ' . ENTRY_FIRST_NAME_MIN_LENGTH . '. אנא נסו שנית;
define('ENTRY_EMAIL_CONTENT_CHECK_ERROR','האם שכחתם את ההודעה? אנו מעוניינים לשמוע מכם. ניתן להקליד הודעה והערות באיזור הכתיבה מטה');

define('NOT_LOGGED_IN_TEXT', 'לא מחובר למערכת');
 