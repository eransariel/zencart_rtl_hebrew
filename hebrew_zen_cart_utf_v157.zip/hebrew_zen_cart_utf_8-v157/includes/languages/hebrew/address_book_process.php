<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 12 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE_1', 'החשבון שלי');
define('NAVBAR_TITLE_2', 'ספר הכתובות');

define('NAVBAR_TITLE_ADD_ENTRY', 'כתובת חדשה');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'ערוך כתובת');
define('NAVBAR_TITLE_DELETE_ENTRY', 'מחק כתובת');

define('HEADING_TITLE_ADD_ENTRY', '<h1>חדש</h1>');
define('HEADING_TITLE_MODIFY_ENTRY', '<h1>ערוך</h1>');
define('HEADING_TITLE_DELETE_ENTRY', '<h1>מחק</h1>');
define('HEADING_TITLE', 'פרטי כתובת');

define('DELETE_ADDRESS_TITLE', 'מחק כתובת');
define('DELETE_ADDRESS_DESCRIPTION', 'האם אתה בטוח כי ברצונך למחוק את הכתובת המסומנת ?');

define('NEW_ADDRESS_TITLE', 'כתובת חדשה');

define('SELECTED_ADDRESS', 'כתובת מסומנת');
define('SET_AS_PRIMARY', 'קבע ככתובת ראשית.');

define('SUCCESS_ADDRESS_BOOK_ENTRY_DELETED', 'הכתובת אותה סימנת הוסרה בהצלחה.');
define('SUCCESS_ADDRESS_BOOK_ENTRY_UPDATED', 'ספר הכתובות עודכן בהצלחה.');

define('WARNING_PRIMARY_ADDRESS_DELETION', 'לא ניתן למחוק כתובת ראשית. אנא קבע כתובת אחרת כראשית ונסה שוב.');

define('ERROR_NONEXISTING_ADDRESS_BOOK_ENTRY', 'כתובת זו אינה קיימת.');
define('ERROR_ADDRESS_BOOK_FULL', 'ספר הכתובות שלך מלא. אנא הסר כתובות אשר לא נדרשות ונסה שוב.');

