<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: shopping_cart.php 3183 2006-03-14 07:58:59Z birdbrain $
 */

define('TEXT_INFORMATION', 'לכל שאלה או בעיה, אנא השתמש בטופס צור קשר');

define('NAVBAR_TITLE', 'תכולת הסל');
define('HEADING_TITLE', 'מוצרים בסל:');
define('HEADING_TITLE_EMPTY', 'סל קניות שלך');
define('TABLE_HEADING_REMOVE', 'הסר');
define('TABLE_HEADING_QUANTITY', 'כמות.');
define('TABLE_HEADING_MODEL', 'מודל');
define('TABLE_HEADING_PRICE', 'מחיר');
define('TEXT_CART_EMPTY', 'הסל ריק.');
//define('SUB_TITLE_SUB_TOTAL', 'סך לפני מיסים:');
define('SUB_TITLE_SUB_TOTAL', 'סך הכל:');
define('SUB_TITLE_TOTAL', 'סך הכל:');

define('OUT_OF_STOCK_CANT_CHECKOUT', 'מוצרים המסומנים ב ' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . ' אינם במלאי או שאין מספיק במלאי בשביל לספק את הזמנתך.<br />אנא שנה את כמות המוצרים המסומנים ב (' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . '). תודה לך.');
define('OUT_OF_STOCK_CAN_CHECKOUT', 'מוצרים המסומנים ב ' . STOCK_MARK_PRODUCT_OUT_OF_STOCK . ' אינם במלאי.<br />מוצרים אלו יתווספו לרשימת ההמתנה למוצר.');

define('TEXT_TOTAL_ITEMS', 'כמות מוצרים: ');
define('TEXT_TOTAL_WEIGHT', '&nbsp;משקל כולל:&nbsp;');
define('TEXT_TOTAL_AMOUNT', '&nbsp;סה"כ:&nbsp;');

define('TEXT_CART_HELP', '<a href="javascript:session_win();">[לעזרה (?)]</a>');
define('TEXT_VISITORS_CART', '<a href="javascript:session_win();">[לעזרה (?)]</a>');

define('TEXT_OPTION_DIVIDER', '&nbsp;-&nbsp;');
