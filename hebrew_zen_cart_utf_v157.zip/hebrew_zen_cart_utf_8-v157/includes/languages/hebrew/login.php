<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: login.php 6352 2007-05-20 21:05:01Z drbyte $
 */

define('NAVBAR_TITLE', 'התחבר');
define('HEADING_TITLE', 'שלום רב, להתחברות הכנס את שם המשתמש והסיסמה');

define('HEADING_NEW_CUSTOMER', 'חדש אצלנו? אנא רשום את פרטיך');
define('HEADING_NEW_CUSTOMER_SPLIT', 'משתמשים חדשים');

define('TEXT_NEW_CUSTOMER_INTRODUCTION', 'יצירת חשבון תאפשר לך לרכוש מוצרים ביתר נוחות ותספק לך שירותים מתקדמים של ניהול ומעקב הזמנות, יצירת פנקס כתובות ועוד.');
define('TEXT_NEW_CUSTOMER_INTRODUCTION_SPLIT', 'יש לך PayPal? רוצה לשלם מהר עם כרטיס אשראי? רוצה לשלם מהר? לחץ כאן לתשלום אקספרס עם PayPal.');
define('TEXT_NEW_CUSTOMER_POST_INTRODUCTION_DIVIDER', '<span class="larger">או</span><br />');
define('TEXT_NEW_CUSTOMER_POST_INTRODUCTION_SPLIT', 'צור חשבון משתמש ב<strong>' . STORE_NAME . '</strong> אשר יתן לךלבצע הזמנות במהירות, לבצע מעקב אחרי הזמנותיך ושלל הטבות והנחות אותן מקבלים המשתמשים הרשומים בחנות.');

define('HEADING_RETURNING_CUSTOMER', 'לקוחות חוזרים ? אנא היכנסו למערכת.');
define('HEADING_RETURNING_CUSTOMER_SPLIT', 'לקוחות חוזרים');

define('TEXT_RETURNING_CUSTOMER_SPLIT', 'בשביל להמשיך, אנא התחבר לחשבונך ב<strong>' . STORE_NAME . '</strong>.');


define('TEXT_PASSWORD_FORGOTTEN', 'שכחת סיסמה?');

define('TEXT_LOGIN_ERROR', 'אנו מצטערים, אך האימייל או הסיסמה אותה סיפקת לא קיימים במערכת.');
define('TEXT_VISITORS_CART', '<strong class="note">הערה:</strong> תכולת סל הקניות שלך עד עכשיו ימוזג לתכולת סל הקניות האישי לאחר שתתחבר.');

define('TABLE_HEADING_PRIVACY_CONDITIONS', '<span class="privacyconditions"> תנאי השימוש.</span>');
define('TEXT_PRIVACY_CONDITIONS_DESCRIPTION', '<span class="privacydescription">אנא עיין בהסכם </span> <a href="' . zen_href_link(FILENAME_PRIVACY, '', 'SSL') . '"><u> בתנאי השימוש.</u></a>.');
define('TEXT_PRIVACY_CONDITIONS_CONFIRM', '<span class="privacyagree">אם הינך מסכים לתנאי השימוש באתר אנא סמן פה V.</span>');

define('ERROR_SECURITY_ERROR', 'הייתה שגיאת אבטחה במהלך תהליך ההתחברות.');

define('TEXT_LOGIN_BANNED', 'שגיאה: גישה נדחתה.');
