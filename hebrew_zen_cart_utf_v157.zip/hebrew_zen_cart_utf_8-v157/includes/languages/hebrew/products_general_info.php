<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: products_general_info.php 6 2006-08-07 15:53:59Z Administrator $
//

define('TEXT_PRODUCT_NOT_FOUND', 'מצטערים, המוצר לא נמצא.');
define('TEXT_CURRENT_REVIEWS', 'ביקורות נוכחיות:');
define('TEXT_MORE_INFORMATION', 'למידע נוסף, אנא בקר <a href="%s" target="_blank">בדף המוצר</a>.');
define('TEXT_DATE_ADDED', 'המוצר נוסף לקטלוג ב %s.');
define('TEXT_DATE_AVAILABLE', '<font color="#ff0000">המוצר יהיה במלאי ב %s.</font>');
define('TEXT_ALSO_PURCHASED_PRODUCTS', 'לקוחות שרכשו מוצר זה גם רכשו...');
define('TEXT_PRODUCT_OPTIONS', '<strong>אנא בחר/י:</strong>');
define('TEXT_PRODUCT_MANUFACTURER', 'מיוצר על ידי: ');
define('TEXT_PRODUCT_WEIGHT', 'משקל משלוח: ');
define('TEXT_PRODUCT_WEIGHT_UNIT', ' גרמים');
define('TEXT_PRODUCT_QUANTITY', ' יחידות במלאי');
define('TEXT_PRODUCT_MODEL', 'דגם: ');



// previous next product
define('PREV_NEXT_PRODUCT', 'Product ');
define('PREV_NEXT_FROM', ' from ');
define('IMAGE_BUTTON_PREVIOUS','Previous Item');
define('IMAGE_BUTTON_NEXT','Next Item');
define('IMAGE_BUTTON_RETURN_TO_PRODUCT_LIST','Back to Product List');

// missing products
//define('TABLE_HEADING_NEW_PRODUCTS', 'New Products For %s');
//define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Upcoming Products');
//define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');

define('TEXT_ATTRIBUTES_PRICE_WAS',' [was: ');
define('TEXT_ATTRIBUTE_IS_FREE',' now is: Free]');
define('TEXT_ONETIME_CHARGE_SYMBOL', ' *');
define('TEXT_ONETIME_CHARGE_DESCRIPTION', ' One time charges may apply');
define('TEXT_ATTRIBUTES_QTY_PRICE_HELP_LINK','Quantity Discounts Available');
define('ATTRIBUTES_QTY_PRICE_SYMBOL', zen_image(DIR_WS_TEMPLATE_ICONS . 'icon_status_green.gif', TEXT_ATTRIBUTES_QTY_PRICE_HELP_LINK, 10, 10) . '&nbsp;');
?>