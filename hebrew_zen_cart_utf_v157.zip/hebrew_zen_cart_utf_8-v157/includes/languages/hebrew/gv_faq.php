<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: gv_faq.php 4155 2006-08-16 17:14:52Z ajeh $
//

define('NAVBAR_TITLE', 'שאלות ותשובות לגבי ' . TEXT_GV_NAME . '');
define('HEADING_TITLE', 'שאלות ותשובות לגבי ' . TEXT_GV_NAME . '');

define('TEXT_INFORMATION', '<a name="Top"></a>
  <a href="'.zen_href_link(FILENAME_GV_FAQ,'faq_item=1','NONSSL').'">רכישת ' . TEXT_GV_NAMES . '</a><br />
  <a href="'.zen_href_link(FILENAME_GV_FAQ,'faq_item=2','NONSSL').'">איך לשלוח ' . TEXT_GV_NAMES . '</a><br />
  <a href="'.zen_href_link(FILENAME_GV_FAQ,'faq_item=3','NONSSL').'">קנייה בעזרת ' . TEXT_GV_NAMES . '</a><br />
  <a href="'.zen_href_link(FILENAME_GV_FAQ,'faq_item=4','NONSSL').'">פדיית ' . TEXT_GV_NAMES . '</a><br />
  <a href="'.zen_href_link(FILENAME_GV_FAQ,'faq_item=5','NONSSL').'">כאשר בעיות מתרחשות</a><br />
');
switch ($_GET['faq_item']) {
  case '1':
define('SUB_HEADING_TITLE','רכישת ' . TEXT_GV_NAMES);
define('SUB_HEADING_TEXT', TEXT_GV_NAMES . ' נרכש כמו כל מוצר אחר בחנות וניתן לשלם עליו בכל אחד מאמצעי התשלום שבחנות.
  ברגע שרכשת ' . TEXT_GV_NAME . ' הוא יצורף לחשבון ה' . TEXT_GV_NAME . ' שלך. אם קיימים קרדיטים בחשבון זה ' . TEXT_GV_NAME . ', תשים לב שהם מוצרים בעגלת הקניות,
  וכמו כן, מוצר קישור לשליחת ' . TEXT_GV_NAME . ' למישהו אחר.');
  break;
  case '2':
define('SUB_HEADING_TITLE','איך לשלוח ' . TEXT_GV_NAMES);
define('SUB_HEADING_TEXT','בשביל לשלוח ' . TEXT_GV_NAME . ' תצטרך/י ללכת לדף שליחת ב' . TEXT_GV_NAME . '.
  תוכל למצוא את הקישור לדף זה בעגלת הקניות בצד ימין.
  כאשר את/ה שולח/ת ' . TEXT_GV_NAME . ', תצטרך/י לספק את המידע הבא.
  שם מקבל הקופון ' . TEXT_GV_NAME . '.
  כתובת הדואר האלקטרוני של מקבל ה' . TEXT_GV_NAME . '.
  הסכום אותו את/ה מעוניין/ת לשלוח. (לתשומת ליבך, אינך חייב/ת לשלוח את כל הסכום אותו יש לך בחשבון ה' . TEXT_GV_NAME . ' שלך.)
  מסר קצר למקבל הקופון.
  אנא וודא/י היטב כי המידע שהקלדת הוא תקין ונכון.');
  break;
  case '3':
  define('SUB_HEADING_TITLE','קנייה בעזרת ' . TEXT_GV_NAMES);
  define('SUB_HEADING_TEXT','אם יש לך קרדיטים בחשבון ה' . TEXT_GV_NAME . ' שלך, תוכל/י להשתמש בהם לצורך קניה באתר.
  בשלב התשלום תתווסף תיבה נוספת בה תצטרך/י להקיש את סכום הקרדיטים אשר ברצונך להשתמש בהם.
  לתשומת לבך, במידה ואין לך מספיק קרדיטים לכיסוי עלות ההזמנה תצטרך/י בכל אופן לבחור עוד דרך תשלום ליתרת ההזמנה
  . כמו כן, במידה ויש לך יותר קרדיטים בחשבון ממחיר ההזמנה, קרדיטים אלו ישארו בחשבונך לקניה הבאה.');
  break;
  case '4':
  define('SUB_HEADING_TITLE','פדיית ' . TEXT_GV_NAMES);
  define('SUB_HEADING_TEXT','אם קיבלת ' . TEXT_GV_NAME . ' באימייל, הודעת המייל מכילה את שם שולח ה' . TEXT_GV_NAME . ',
  יחד עם מסר קצר ממנו/ה. האימייל יכיל בנוסף את ' . TEXT_GV_REDEEM . ' של ה' . TEXT_GV_NAME . '. זה קרוב לוודאי רעיון טוב להדפיס מייל זה לכל צרה שלא תהיה.
  כעת תוכל לפדות/להתשמש ב' . TEXT_GV_NAME . ' זה בשתי דרכים.<br /><br />
  1. לחיצה על הקישור המצורף במייל.
  קישור זה ייקח אותך לדף הפדייה של ה' . TEXT_GV_NAME . '. שם תדרש/י ליצור חשבון משתמש לפני אישור ה' . TEXT_GV_NAME . ' והשמתו בחשבונך. אחרי יצירת החשבון ואישור ה'. TEXT_GV_NAME .' הנך מוכן/ה לרכישה באמצעותו בחנות.<br /><br />
  2. במהלך ביצוע תשלום הזמנה בחנות, תופיע תיבה להכנסת ' . TEXT_GV_REDEEM . '. הכנס/י את ' . TEXT_GV_REDEEM . ' לתוך התיבה, לחץ על כפתור הפדייה. ה' . TEXT_GV_NAME . ' יאושר ויתווסף לחשבונך.
  ותוכל/י להשתמש בשוויו.');
  break;
  case '5':
  define('SUB_HEADING_TITLE','כאשר בעיות מתרחשות.');
  define('SUB_HEADING_TEXT','לכל שאלה, בעיה ו/או בקשה בנושא ' . TEXT_GV_NAME . ' אנא צור עימי קשר במייל '. STORE_OWNER_EMAIL_ADDRESS . '. אנא וודא/י שהינך מספק/ת כמה שיותר מידה על הבעיה/המצב. תודה. ');
  break;
  default:
  define('SUB_HEADING_TITLE','');
  define('SUB_HEADING_TEXT','אנא בחר מהשאלות לעיל.');

  }

  define('TEXT_GV_REDEEM_INFO', 'אנא הכנס קוד ' . TEXT_GV_NAME . ': ');
  define('TEXT_GV_REDEEM_ID', 'קוד קופון:');
