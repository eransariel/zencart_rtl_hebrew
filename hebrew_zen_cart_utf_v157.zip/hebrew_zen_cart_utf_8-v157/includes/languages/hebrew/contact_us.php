<?php
/**
 * @copyright Copyright 2003-2021 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Eran Ariel 2021 modified in v1.5.7b $
 */

define('HEADING_TITLE', 'יצירת קשר');
define('NAVBAR_TITLE', 'יצירת קשר');
define('TEXT_SUCCESS', 'הודעתך נשלחה בהצלחה.');
define('EMAIL_SUBJECT', 'הודעה מ ' . STORE_NAME);

define('ENTRY_NAME', 'שם מלא:');
define('ENTRY_EMAIL', 'כתובת אימייל:');
define('ENTRY_TELEPHONE', 'מספר טלפון:');
define('ENTRY_ENQUIRY', 'ההודעה:');

define('SEND_TO_TEXT','שלח אימייל ל:');
define('ENTRY_EMAIL_NAME_CHECK_ERROR','מצטערים. האם השם שהכנסת נכון? אורך השם צריך להיות לפחות ' . ENTRY_FIRST_NAME_MIN_LENGTH . ' תווים. אנא נסה/י שוב.');
define('ENTRY_EMAIL_CONTENT_CHECK_ERROR','האם שכחת את ההודעה? נשמח לשמוע ממך! הקלד/י את ההודעה בתיבה למטה.');

define('NOT_LOGGED_IN_TEXT', 'לא מחובר/ת');
