<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 10 Modified in v1.5.7 $
 */


define('NAVBAR_TITLE_1', 'תהליך הרכישה');
define('NAVBAR_TITLE_2', 'שינוי כתובת החיוב');

define('HEADING_TITLE', 'שינוי מידע על החיוב');

define('TABLE_HEADING_PAYMENT_ADDRESS', 'כתובת לחיוב');
define('TEXT_SELECTED_PAYMENT_DESTINATION', 'זוהי הכתובת אליה תשלח הקבלה.');
define('TITLE_PAYMENT_ADDRESS', '<strong>כתובת לחיוב:</strong>');

define('TEXT_SELECT_OTHER_PAYMENT_DESTINATION', 'סמן תיבה זו אם ברצונך לקבל את הקבלה בכתובת השונה מכתובת אליה ישלח המוצר.');
define('TITLE_PLEASE_SELECT', 'בחר');

define('TABLE_HEADING_NEW_PAYMENT_ADDRESS', '...או בחר מתוך ספר הכתובות');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', '<strong>המשך</strong>');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', '- לבחירת שיטת התשלום.');
