<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2021 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Eran Ariel 2021 modified in v1.5.7b $

 */

define('TEXT_MAIN','This is the main define statement for the page for english when no template defined file exists. It is located in: <strong>/includes/languages/english/index.php</strong>');

// Showcase vs Store
if (STORE_STATUS == '0') {
  define('TEXT_GREETING_GUEST', '  <span class="greetUser"> </span><a href="%s">כניסה ו\או הרשמה למערכת </a> '); 
} else {
  define('TEXT_GREETING_GUEST', 'ברוך הבא, תהנה/י מביקורך בקטלוג!');
}

define('TEXT_GREETING_PERSONAL', 'שלום <span class="greetUser">%s</span>! האם תרצה/י לראות את <a href="%s">המוצרים החדשים</a>?');

define('TEXT_INFORMATION', '');

//moved to english
//define('TABLE_HEADING_FEATURED_PRODUCTS','Featured Products');

//define('TABLE_HEADING_NEW_PRODUCTS', 'New Products For %s');
//define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Upcoming Products');
//define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');

if ( ($category_depth == 'products') || (zen_check_url_get_terms()) ) {
  // This section deals with product-listing page contents
  define('HEADING_TITLE', 'מוצרים קיימים');
  define('TABLE_HEADING_IMAGE', 'תמונה');
  define('TABLE_HEADING_MODEL', '');
  define('TABLE_HEADING_PRODUCTS', 'שם');
  define('TABLE_HEADING_MANUFACTURER', 'יצרן');
  define('TABLE_HEADING_QUANTITY', 'כמות');
  define('TABLE_HEADING_PRICE', 'מחיר');
  define('TABLE_HEADING_WEIGHT', 'משקל');
  define('TABLE_HEADING_BUY_NOW', 'הזמן!');
  define('TEXT_NO_PRODUCTS', 'אין מוצרים בקטגוריה הנוכחית.');
  define('TEXT_NO_PRODUCTS2', 'אין מוצרים עבור יצרן זה.');
  define('TEXT_NUMBER_OF_PRODUCTS', 'מספר המוצרים: ');
  define('TEXT_SHOW', '<b>סדר לפי:</b> ');
  define('TEXT_BUY', 'הזמן 1 \'');
  define('TEXT_NOW', '\' עכשיו');
  define('TEXT_ALL_CATEGORIES', 'כל הקטגוריות');
  define('TEXT_ALL_MANUFACTURERS', 'כל היצרנים');
} elseif ($category_depth == 'top') {
  // This section deals with the "home" page at the top level with no options/products selected
  /*Replace this text with the headline you would like for your shop. For example: 'Welcome to My SHOP!'*/
  define('HEADING_TITLE', '');
} elseif ($category_depth == 'nested') {
  // This section deals with displaying a subcategory
  /*Replace this line with the headline you would like for your shop. For example: 'Welcome to My SHOP!'*/
  define('HEADING_TITLE', '');
}
