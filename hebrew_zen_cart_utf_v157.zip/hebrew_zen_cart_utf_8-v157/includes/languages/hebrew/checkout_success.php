<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Steve 2020 May 27 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE_1', 'תהליך הרכישה');
define('NAVBAR_TITLE_2', 'תודה רבה על ההזמנה');

define('HEADING_TITLE', 'תודה רבה!');

define('TEXT_SUCCESS', 'תודה');
define('TEXT_NOTIFY_PRODUCTS', 'אנא שלח לי דואר אלקטרוני כאשר יהיו עדכונים על מוצר זה:');
define('TEXT_SEE_ORDERS', 'כדי לראות את מעקב הזמנותיך,  <a href="' . zen_href_link(FILENAME_ACCOUNT, '', 'SSL') . '">\'לחץ כאן\'</a> ואז על \'הראה כל ההזמנות\'.');
define('TEXT_CONTACT_STORE_OWNER', 'נשמח לענות על כל שאלה או בירור. <a href="' . zen_href_link(FILENAME_CONTACT_US) . '">פרטי התקשרות</a>.');
define('TEXT_THANKS_FOR_SHOPPING', 'תודה שקניתם אצלנו!');

define('TABLE_HEADING_COMMENTS', '');

define('FOOTER_DOWNLOAD', 'תוכל להוריד את המוצרים במועד אחר דרך \'%s\'');

define('TEXT_YOUR_ORDER_NUMBER', '<strong>מספר הזמנתך הוא:</strong> ');

define('TEXT_CHECKOUT_LOGOFF_GUEST', 'שים לב, בשביל לסיים את קנייתך נוצר חשבון זמני. ניתן לסגור חשבון זה על ידי לחיצה על התנתקות. כמו כן לחיצה על כפתור ההתנתקות תוודא שהבן אדם שישתמש אחריך במחשב לא יראה את פרטיך האישיים אשר הוכנסו בעת הקנייה. אם ברצונך להמשיך להסתובב בחנות - תהנה/י! ניתן להתנתק בכל עת על ידי לחיצה על הכפתור בראש הדף.');
define('TEXT_CHECKOUT_LOGOFF_CUSTOMER', 'תודה שקנית! אנא לחץ על כפתור ההתנתקות בשביל לוודא שהבן אדם שמשתמש אחריך במחשב לא יראה את פרטיך האישיים.');


define('HEADING_ORDER_NUMBER', 'Order #%s');
define('HEADING_ORDER_DATE', 'תאריך ההזמנה: ');

define('HEADING_DELIVERY_ADDRESS', 'כתובת משלוח');
define('HEADING_SHIPPING_METHOD', 'אופן\שיטת המשלוח');

define('HEADING_PRODUCTS', 'פריטים');
define('HEADING_TAX', 'מס');
define('HEADING_TOTAL', 'סה"כ');
define('HEADING_QUANTITY', 'כמות');

define('HEADING_BILLING_ADDRESS', 'כתובת החיוב');
define('HEADING_PAYMENT_METHOD', 'שיטת התשלום');

define('HEADING_ORDER_HISTORY', 'סטטוס היסטוריה &amp; הערות');
define('TABLE_HEADING_STATUS_DATE', 'תאריך');
define('TABLE_HEADING_STATUS_ORDER_STATUS', 'סטטוס ההזמנה');
define('TABLE_HEADING_STATUS_COMMENTS', 'הערות');
define('QUANTITY_SUFFIX', '&nbsp;ea.  ');
define('ORDER_HEADING_DIVIDER', '&nbsp;-&nbsp;');

