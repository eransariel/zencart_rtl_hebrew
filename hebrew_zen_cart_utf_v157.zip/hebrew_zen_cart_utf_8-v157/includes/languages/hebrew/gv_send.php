<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: gv_send.php 3421 2006-04-12 04:16:14Z drbyte $
 */

define('HEADING_TITLE', 'שלח ' . TEXT_GV_NAME);
define('HEADING_TITLE_CONFIRM_SEND', 'שלח ' . TEXT_GV_NAME . ' אישור');
define('HEADING_TITLE_COMPLETED', TEXT_GV_NAME . ' נשלח');
define('NAVBAR_TITLE', 'שלח ' . TEXT_GV_NAME);
define('EMAIL_SUBJECT', 'הודעה מאת ' . STORE_NAME);
define('HEADING_TEXT','<br />אנא הכנת למטה את פרטי ה' . TEXT_GV_NAME . ' שברצונך לשלוח. לעוד מידע אנא ראה את <a href="' . zen_href_link(FILENAME_GV_FAQ, '', 'NONSSL').'">' . GV_FAQ . '.</a><br />');
define('ENTRY_NAME', 'שם המקבל:');
define('ENTRY_EMAIL', 'כתובת דואר אלקטרוני של המקבל:');
define('ENTRY_MESSAGE', 'ההודעה שלך:');
define('ENTRY_AMOUNT', 'כמות לשלוח:');
define('ERROR_ENTRY_TO_NAME_CHECK', 'שם המקבל לא תקין. אנא הכנס שם מקבל בשנית. ');
define('ERROR_ENTRY_AMOUNT_CHECK', '&nbsp;&nbsp;<span class="errorText">סכום לא קביל</span>');
define('ERROR_ENTRY_EMAIL_ADDRESS_CHECK', '&nbsp;&nbsp;<span class="errorText">כתובת דואר אלקטרוני לא קבילה</span>');
define('MAIN_MESSAGE', 'החלטת לשלוח ' . TEXT_GV_NAME . ' בסכום %s ל %s שכתובת הדואר האלקטרוני שלו/ה היא %s<br /><br />המסר שנשלח עם הקופון הוא:<br /><br />%s<br /><br />' . 'קיבלת ' . TEXT_GV_NAME . ' בסכום של %s מאת %s');
define('SECONDARY_MESSAGE', '%s,<br /><br />' . 'נשלח אליך ' . TEXT_GV_NAME . ' בסכום של %s על ידי %s');
define('PERSONAL_MESSAGE', '%s מוסר');
define('TEXT_SUCCESS', 'איחולי! ה' . TEXT_GV_NAME . ' שלך נשלח.');
define('TEXT_SEND_ANOTHER', 'האם תרצה/י לשלוח עוד ' . TEXT_GV_NAME . '?');
define('TEXT_AVAILABLE_BALANCE',  'חשבון קופונים');

define('EMAIL_GV_TEXT_SUBJECT', 'מתנה מאת %s');
define('EMAIL_SEPARATOR', '----------------------------------------------------------------------------------------');
define('EMAIL_GV_TEXT_HEADER', 'איחולי! קיבלת' . TEXT_GV_NAME . ' בסכום של %s');
define('EMAIL_GV_FROM', '' . TEXT_GV_NAME . ' זה נשלח אליך מאת %s');
define('EMAIL_GV_MESSAGE', 'עם ההודעה הבאה: ');
define('EMAIL_GV_SEND_TO', 'היי, %s');
define('EMAIL_GV_REDEEM', 'בשביל לפדות ' . TEXT_GV_NAME . ' זה, אנא הקלק על הלינק מתחת ובנוסף אנא רשום את מספר ' . TEXT_GV_REDEEM . ': %s  למקרה שיהיו תקלות.');
define('EMAIL_GV_LINK', 'לפדייה אנא הקלק כאן');
define('EMAIL_GV_VISIT', ' או בקר ');
define('EMAIL_GV_ENTER', ' והכנס את מספר ה' . TEXT_GV_REDEEM . ' ');
define('EMAIL_GV_FIXED_FOOTER', 'במידה והנך נתקל בבעיות בפדייה ' . TEXT_GV_NAME . ' בעת שימוש בלינק האוטומטי לעיל, ' . "\n" .
                                'תוכל גם להכניס את מספר ה' . TEXT_GV_NAME . ' ' . TEXT_GV_REDEEM . ' במהלך תשלום בחנות.');
define('EMAIL_GV_SHOP_FOOTER', '');
