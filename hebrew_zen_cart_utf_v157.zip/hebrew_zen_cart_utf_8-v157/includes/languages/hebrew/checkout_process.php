<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Steve 2020 May 27 Modified in v1.5.7 $
 */


define('EMAIL_TEXT_SUBJECT', 'אישור ההזמנה');
define('EMAIL_TEXT_HEADER', 'אישור ההזמנה');
define('EMAIL_TEXT_FROM',' מ ');  //added to the EMAIL_TEXT_HEADER, above on text-only emails
define('EMAIL_THANKS_FOR_SHOPPING','תודה שקנית אצלנו!');
define('EMAIL_DETAILS_FOLLOW','הפרטים הבאים הם של ההזמנה שלך.');
define('EMAIL_TEXT_ORDER_NUMBER', 'מספר ההזמנה:');
define('EMAIL_TEXT_INVOICE_URL', 'חשבונית מפורטת:');
define('EMAIL_TEXT_INVOICE_URL_CLICK', 'לחץ כאן לחשבונית מפורטת');
define('EMAIL_TEXT_DATE_ORDERED', 'תאריך ההזמנה:');
define('EMAIL_TEXT_PRODUCTS', 'מוצרים');
define('EMAIL_TEXT_SUBTOTAL', 'סכום ביניים:');
define('EMAIL_TEXT_TAX', 'מס:        ');
define('EMAIL_TEXT_SHIPPING', 'משלוח: ');
define('EMAIL_TEXT_TOTAL', 'סך הכל:    ');
define('EMAIL_TEXT_DELIVERY_ADDRESS', 'כתובת משלוח');
define('EMAIL_TEXT_BILLING_ADDRESS', 'כתובת חיוב');
define('EMAIL_TEXT_PAYMENT_METHOD', 'דרך תשלום');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('TEXT_EMAIL_VIA', 'דרך');

// suggest not using # vs No as some spamm protection block emails with these subjects
define('EMAIL_ORDER_NUMBER_SUBJECT', ' מספר: ');
define('HEADING_ADDRESS_INFORMATION','כתובת');
define('HEADING_SHIPPING_METHOD','דרך משלוח');
