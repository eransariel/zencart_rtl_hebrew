<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @copyright Originally Programmed By: Christopher Bradley (www.wizardsandwars.com) for OsCommerce
 * @copyright Modified by Jim Keebaugh for OsCommerce
 * @copyright Adapted for Zen Cart
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: unsubscribe.php 3159 2006-03-11 01:35:04Z drbyte $
 */

define('NAVBAR_TITLE', 'ביטול הרשמה');
define('HEADING_TITLE', 'ביטול הרשמה לרשימת התפוצה');

define('UNSUBSCRIBE_TEXT_INFORMATION', '<br />אנו מצטערים כי ברצונך להימחק מרשימת התפוצה שלנו. אם יש לך חששות אבטחה אנא קרא את <a href="' . zen_href_link(FILENAME_PRIVACY,'','NONSSL') . '"><u>הצהרת האבטחה</u></a>.<br /><br />אלו הרשומים לרשימת התפוצה, מקבלים מידע על עדכונים, מבצעים והנחות ייחודיות בחנות.<br /><br />אם עדיין אין ברצונך לקבל עלון זה, אנא לחץ/י על הכפתור למטה. ');
define('UNSUBSCRIBE_TEXT_NO_ADDRESS_GIVEN', '<br />אנו מצטערים כי ברצונך להימחק מרשימת התפוצה שלנו. אם יש לך חששות אבטחה אנא קרא את <a href="' . zen_href_link(FILENAME_PRIVACY,'','NONSSL') . '"><u>הצהרת האבטחה</u></a>.<br /><br />אלו הרשומים לרשימת התפוצה, מקבלים מידע על עדכונים, מבצעים והנחות ייחודיות בחנות.<br /><br />אם עדיין אין ברצונך לקבל עלון זה, אנא לחץ/י על הכפתור למטה. מפה תועבר לדף החשבון שלך שם תדרש לעדכן את הפרטים הנדרשים.');
define('UNSUBSCRIBE_DONE_TEXT_INFORMATION', '<br />לבקשתך, כתובת האימייל הרשומת למטה הוסרה מרשימת התפוצה שלנו. <br /><br />');
define('UNSUBSCRIBE_ERROR_INFORMATION', '<br />כתובת האימייל שמסרת לא נמצא במאגרי המידע שלנו, ייתכן כי הוסרה כבר. <br /><br />');
?>