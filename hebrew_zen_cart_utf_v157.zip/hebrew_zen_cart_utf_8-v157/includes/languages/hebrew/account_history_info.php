<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Eran Ariel Modified Jan 2021 in v1.5.7b $
 */

define('NAVBAR_TITLE', 'החשבון שלי');
define('NAVBAR_TITLE_1', 'חשבון');
define('NAVBAR_TITLE_2', 'מעקב');
define('NAVBAR_TITLE_3', 'הזמנה מס %s');

define('HEADING_TITLE', 'פרטי ההזמנה');

define('HEADING_ORDER_NUMBER', 'הזמנה מס %s');
define('HEADING_ORDER_DATE', 'תאריך:');
define('HEADING_ORDER_TOTAL', 'עלות כוללת:');

define('HEADING_DELIVERY_ADDRESS', 'כתובת המשלוח');
define('HEADING_SHIPPING_METHOD', 'שיטת החיוב');

define('HEADING_PRODUCTS', 'מוצרים');
define('HEADING_TAX', 'מס');
define('HEADING_TOTAL', 'סך');
define('HEADING_QUANTITY', 'כמות');

define('HEADING_BILLING_ADDRESS', 'כתובת לחיוב');
define('HEADING_PAYMENT_METHOD', 'שיטת התשלום');

define('HEADING_ORDER_HISTORY', 'מעקב סטטוס והערות');
define('TEXT_NO_COMMENTS_AVAILABLE', 'אין הערות.');
define('TABLE_HEADING_STATUS_DATE', 'תאריך');
define('TABLE_HEADING_STATUS_ORDER_STATUS', 'סטטוס הזמנה');
define('TABLE_HEADING_STATUS_COMMENTS', 'הערות');
define('QUANTITY_SUFFIX', '&nbsp;יח\'  ');
define('ORDER_HEADING_DIVIDER', '&nbsp;-&nbsp;');
define('TEXT_OPTION_DIVIDER', '&nbsp;-&nbsp;');

