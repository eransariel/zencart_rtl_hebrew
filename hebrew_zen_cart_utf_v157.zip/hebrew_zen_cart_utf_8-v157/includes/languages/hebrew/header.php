<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: header.php 2940 2006-02-02 04:29:05Z drbyte $
 */

// header text in includes/header.php
define('HEADER_TITLE_CREATE_ACCOUNT', 'צור חשבון');
define('HEADER_TITLE_MY_ACCOUNT', 'החשבון שלי');
define('HEADER_TITLE_CART_CONTENTS', 'סל קניות');
define('HEADER_TITLE_CHECKOUT', 'לקופה');
define('HEADER_TITLE_TOP', 'למעלה');
define('HEADER_TITLE_CATALOG', 'ראשי');
define('HEADER_TITLE_LOGOFF', 'התנתק');
define('HEADER_TITLE_LOGIN', 'התחבר');

// added defines for header alt and text
define('HEADER_ALT_TEXT', '');
define('HEADER_SALES_TEXT', '');
define('HEADER_LOGO_WIDTH', '200px');
define('HEADER_LOGO_HEIGHT', '23px');
define('HEADER_LOGO_IMAGE', 'logo.gif');

// header Search Button/Box Search Button
define('HEADER_SEARCH_BUTTON','חפש');
define('HEADER_SEARCH_DEFAULT_TEXT','הכנס מילות חיפוש'); 
define('SEARCH_DEFAULT_TEXT', 'חפש כאן');

