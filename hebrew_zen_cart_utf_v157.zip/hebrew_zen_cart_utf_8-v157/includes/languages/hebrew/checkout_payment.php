<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 May 16 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE_1', 'תהליך הרכישה');
define('NAVBAR_TITLE_2', 'שיטת התשלום');

define('HEADING_TITLE', 'שלב 2 מתוך 3 - פרטי התשלום');

define('TABLE_HEADING_BILLING_ADDRESS', 'כתובת לחיוב');
define('TEXT_SELECTED_BILLING_DESTINATION', 'כתובת זו משמשת למשלוח הקבלה.');
define('TITLE_BILLING_ADDRESS', 'כתובת לחיוב:');

define('TABLE_HEADING_PAYMENT_METHOD', 'שיטת התשלום');
define('TEXT_SELECT_PAYMENT_METHOD', 'בחר שיטת תשלום.');
define('TITLE_PLEASE_SELECT', 'בחר');
define('TEXT_ENTER_PAYMENT_INFORMATION', 'כרגע זוהי הינה שיטת התשלום היחידה אשר קיימת.');
define('TABLE_HEADING_COMMENTS', 'הערות או הוראות מיוחדות');
define('TITLE_NO_PAYMENT_OPTIONS_AVAILABLE', 'לא זמין כרגע');
define('TEXT_NO_PAYMENT_OPTIONS_AVAILABLE','<span class="alert">מצטערים, כגע לא ניתן לקבל תשלום מאיזורך.</span><br />אנא צור קשר עימנו למציאת פתרון תשלום.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', '<strong>המשך לשלב 3</strong>');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', '- כדי לאשר את הזמנתך.');

define('TABLE_HEADING_CONDITIONS', '<span class="termsconditions">תנאי השימוש.</span>');
define('TEXT_CONDITIONS_DESCRIPTION', '<span class="termsdescription">אנא עיין בהסכם <a href="' . zen_href_link(FILENAME_CONDITIONS, '', 'SSL') . '"><span class="pseudolink"><u>בתנאי השימוש</u></span></a>.');
define('TEXT_CONDITIONS_CONFIRM', '<span class="termsiagree">אם הינך מסכים לתנאי השימוש באתר אנא סמן פה V.</span>');

define('TEXT_CHECKOUT_AMOUNT_DUE', 'סך הכל לתשלום: ');
define('TEXT_YOUR_TOTAL','סכום לתשלום');
