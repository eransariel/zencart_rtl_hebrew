<?php
/**
 * @copyright Copyright 2003-2021 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Eran Ariel 2021 odified in v1.5.7b $
 */


define('NAVBAR_TITLE', 'החשבון שלי');
define('HEADING_TITLE', 'פרטי החשבון שלי');

define('OVERVIEW_TITLE', 'מידע כללי');
define('OVERVIEW_SHOW_ALL_ORDERS', '(הראה כל ההזמנות)');
define('OVERVIEW_PREVIOUS_ORDERS', 'הזמנות קודמות');
define('TABLE_HEADING_DATE', 'Date');
define('TABLE_HEADING_ORDER_NUMBER', 'מס\'');
define('TABLE_HEADING_SHIPPED_TO', 'משלוח ל');
define('TABLE_HEADING_STATUS', 'סטאטוס');
define('TABLE_HEADING_TOTAL', 'סך הכל');
define('TABLE_HEADING_VIEW', 'תצוגה');

define('MY_ACCOUNT_TITLE', 'החשבון שלי');
define('MY_ACCOUNT_INFORMATION', 'ראה או שנה את פרטי החשבון');
define('MY_ACCOUNT_ADDRESS_BOOK', 'ראה או שנה את הכתובות');
define('MY_ACCOUNT_PASSWORD', 'שינוי סיסמה');

define('MY_ORDERS_TITLE', 'הזמנות');
define('MY_ORDERS_VIEW', 'הראה את כל הזמנותי');

define('EMAIL_NOTIFICATIONS_TITLE', 'הודעה בדואר');
define('EMAIL_NOTIFICATIONS_NEWSLETTERS', 'הרשם או בטל שליחת עדכונים');
define('EMAIL_NOTIFICATIONS_PRODUCTS', 'הרשם או בטל את העדכונים למוצרים');
