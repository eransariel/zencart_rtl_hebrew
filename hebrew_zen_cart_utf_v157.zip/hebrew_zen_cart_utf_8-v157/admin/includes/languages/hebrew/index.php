<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 08 Modified in v1.5.7 $
 */

define('HEADING_TITLE', 'בחר באפשרויות....');

define('BOX_TITLE_ORDERS', 'הזמנות');
define('BOX_TITLE_STATISTICS', 'סטטיסטיקה');

define('BOX_TITLE_FEATURES_SALES', 'מבצעים / מוצעים (featured) / מכירות');

define('WO_GRAPH_TITLE', 'מחוברים לאתר כרגע:');
define('WO_GRAPH_MORE', 'עוד...');
define('WO_GRAPH_REGISTERED', 'משתמשים:');
define('WO_GRAPH_GUEST', 'אורחים:');
define('WO_GRAPH_SPIDER', 'סורק מנועי חיפוש:');
define('WO_GRAPH_TOTAL', 'סה"כ:');
define('WHOS_ONLINE_ACTIVE_TEXT', 'עגלות קניות פעילות');
define('WHOS_ONLINE_INACTIVE_TEXT', 'עגלות קניות לא פעילות');
define('WHOS_ONLINE_ACTIVE_NO_CART_TEXT', 'פעיל ללא עגלת קניות');
define('WHOS_ONLINE_INACTIVE_NO_CART_TEXT', 'אינו פעיל ללא עגלות קניות');

define('DASHBOARD_DAY', 'יום');
define('DASHBOARD_SESSIONS', 'מספר ה-Sessions');
define('DASHBOARD_TOTAL', 'סה"כ:');
define('DASHBOARD_MONTH', 'חודש');
define('DASHBOARD_SALES', 'מכירות');



define('TEXT_COUNTER_HISTORY_TITLE', 'היסטוריית מבקרים - %s הימים האחרונים');

define('TEXT_MONTHLY_SALES_TITLE', ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;מכירות חודשיות (לא כולל משלוח) ');
define('TEXT_CLICK_FOR_COMPLETE_DETAILS', 'לחץ כאן לפרטים מלאים ...');

define('TEXT_SALES_TODAY', 'מכירות <strong>Today</strong> (%s) &nbsp;<strong>$%s</strong>');
define('TEXT_SALES_YESTERDAY', '<strong>Yesterday</strong> (%s) &nbsp;<strong>$%s</strong>');

define('BOX_ENTRY_CUSTOMERS', 'לקוחות:');
define('BOX_ENTRY_NEWSLETTERS', 'מנויים לרשימות תפוצה:');

define('BOX_ENTRY_PRODUCTS', 'מוצרים\פריטים:');
define('BOX_ENTRY_PRODUCTS_OFF', 'פריטים לא פעילים:');
define('BOX_ENTRY_REVIEWS', 'חוות דעת שנכתבו:');
define('BOX_ENTRY_REVIEWS_PENDING', 'חוות דעת בהמתנה לאישור:');

define('BOX_ENTRY_NEW_CUSTOMERS', 'לרוחות חדשים:');
define('BOX_ENTRY_NEW_ORDERS', 'הזמנות חדשות');

define('BOX_ENTRY_SPECIALS_EXPIRED', 'הצעות מיוחדות "specials" שאינן פעילות');
define('BOX_ENTRY_FEATURED_EXPIRED', 'פריטים המוגדרים באתר בתור "featured" (מוצעים\מומלצים) שאינם פעילים');
define('BOX_ENTRY_SALEMAKER_EXPIRED', 'מבצעי מכירות "sales" שאינם פעילים');

define('BOX_ENTRY_SPECIALS_ACTIVE', 'הצעות מיוחדות "specials" פעילות');
define('BOX_ENTRY_FEATURED_ACTIVE', 'פריטים המוגדרים באתר בתור "featured" (מוצעים\מומלצים) פעילים');
define('BOX_ENTRY_SALEMAKER_ACTIVE', 'מבצעי מכירות "sales" פעילות');

define('SESSION', 'Session');
define('TOTAL', 'סה"כ');

define('TEXT_UPDATE', 'עדכון');

define('TEXT_STORE_NAME', 'שם החנות');
define('TEXT_STORE_OWNER', 'הבעלים');
define('TEXT_STORE_OWNER_EMAIL', 'כתובות מייל של בעל החנות');
define('TEXT_STORE_COUNTRY', 'מדינה');
define('TEXT_STORE_ZONE', 'איזור (zone) החנות');
define('TEXT_STORE_ADDRESS', 'Store Address');
define('HEADING_TITLE_WIZARD', 'Initial Setup Wizard');
define('TEXT_STORE_DETAILS', 'Please provide details of your store. All fields are required');

define('ADMIN_NAV_DATE_TIME_FORMAT', '%A %d %b %Y %X'); // this is used for strftime()
